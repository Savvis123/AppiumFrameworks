
package contract;

public class ResponseContainer {
   	private String apiVersion;
   	private Data data;

 	public String getApiVersion(){
		return this.apiVersion;
	}
	public void setApiVersion(String apiVersion){
		this.apiVersion = apiVersion;
	}
 	public Data getData(){
		return this.data;
	}
	public void setData(Data data){
		this.data = data;
	}
}
