
package contract;

public class Restriction {
   	private String countries;
   	private String relationship;
   	private String type;

 	public String getCountries(){
		return this.countries;
	}
	public void setCountries(String countries){
		this.countries = countries;
	}
 	public String getRelationship(){
		return this.relationship;
	}
	public void setRelationship(String relationship){
		this.relationship = relationship;
	}
 	public String getType(){
		return this.type;
	}
	public void setType(String type){
		this.type = type;
	}
}
