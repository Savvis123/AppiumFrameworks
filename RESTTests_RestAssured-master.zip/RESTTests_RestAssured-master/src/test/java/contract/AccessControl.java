
package contract;

public class AccessControl{
   	private String autoPlay;
   	private String comment;
   	private String commentVote;
   	private String embed;
   	private String list;
   	private String rate;
   	private String syndicate;
   	private String videoRespond;

 	public String getAutoPlay(){
		return this.autoPlay;
	}
	public void setAutoPlay(String autoPlay){
		this.autoPlay = autoPlay;
	}
 	public String getComment(){
		return this.comment;
	}
	public void setComment(String comment){
		this.comment = comment;
	}
 	public String getCommentVote(){
		return this.commentVote;
	}
	public void setCommentVote(String commentVote){
		this.commentVote = commentVote;
	}
 	public String getEmbed(){
		return this.embed;
	}
	public void setEmbed(String embed){
		this.embed = embed;
	}
 	public String getList(){
		return this.list;
	}
	public void setList(String list){
		this.list = list;
	}
 	public String getRate(){
		return this.rate;
	}
	public void setRate(String rate){
		this.rate = rate;
	}
 	public String getSyndicate(){
		return this.syndicate;
	}
	public void setSyndicate(String syndicate){
		this.syndicate = syndicate;
	}
 	public String getVideoRespond(){
		return this.videoRespond;
	}
	public void setVideoRespond(String videoRespond){
		this.videoRespond = videoRespond;
	}
}
