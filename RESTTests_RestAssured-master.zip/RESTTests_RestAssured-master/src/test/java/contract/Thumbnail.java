
package contract;

import java.util.List;

public class Thumbnail{
   	private String hqDefault;
   	private String sqDefault;

 	public String getHqDefault(){
		return this.hqDefault;
	}
	public void setHqDefault(String hqDefault){
		this.hqDefault = hqDefault;
	}
 	public String getSqDefault(){
		return this.sqDefault;
	}
	public void setSqDefault(String sqDefault){
		this.sqDefault = sqDefault;
	}
}
