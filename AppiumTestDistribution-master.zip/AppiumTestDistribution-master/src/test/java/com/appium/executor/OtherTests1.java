package com.appium.executor;

import org.testng.annotations.Test;

public class OtherTests1 {

    @Test public void test1() {

    }

    @Test public void test2() {

    }
}
