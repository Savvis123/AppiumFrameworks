package com.appium.utils;

public enum OSType {
    ANDROID, iOS, BOTH
}
