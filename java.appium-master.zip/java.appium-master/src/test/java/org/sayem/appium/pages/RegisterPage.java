package org.sayem.appium.pages;

/**
 * Created by sayem on 4/25/15.
 */
public class RegisterPage {
}
