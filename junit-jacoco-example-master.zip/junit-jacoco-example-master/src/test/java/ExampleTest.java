import org.junit.Test;

public class ExampleTest {

	@Test
	public void verifySomeRandomMethod() {
		Example junitTest = new Example();
		junitTest.someRandomMethod(11, 12);
	}
}
