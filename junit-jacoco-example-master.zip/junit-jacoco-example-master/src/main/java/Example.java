
public class Example {
	
	 public long someRandomMethod(int a, int b) {
	    	
	    	if (a > 10 && b > 10){
	    		return a+b;
	    	}
	    	else{
	    		return a-b;
	    	}
	       
	    }
}
