package io.appium.java_client.pagefactory_tests.widget.tests.android;

import org.openqa.selenium.WebElement;

public class ExtendedAndroidWidget extends AnnotatedAndroidWidget {
    protected ExtendedAndroidWidget(WebElement element) {
        super(element);
    }
}
