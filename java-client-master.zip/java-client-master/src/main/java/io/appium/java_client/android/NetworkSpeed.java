package io.appium.java_client.android;

public enum NetworkSpeed {
    GSM, SCSD, GPRS, EDGE, UMTS, HSDPA, LTE, EVDO, FULL
}
