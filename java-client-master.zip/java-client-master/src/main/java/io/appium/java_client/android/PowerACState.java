package io.appium.java_client.android;

public enum PowerACState {
    ON, OFF
}
