package io.appium.java_client.android;

public enum GsmVoiceState {
    ON, OFF, DENIED, SEARCHING, ROAMING, HOME, UNREGISTERED
}
